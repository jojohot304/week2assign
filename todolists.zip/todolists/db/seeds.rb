# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

User.destroy_all
Profile.destroy_all
TodoList.destroy_all
TodoItem.destroy_all

users_info = {"Carly Fiorina"=>1954,"Donald Trump"=>1946,"Ben Carson"=>1951,"Hillary Clinton"=>1947}
users_gender = {"Carly Fiorina"=>"female","Donald Trump"=>"male","Ben Carson"=>"male","Hillary Clinton"=>"female"}

users_info.each do  |key,value|
	User.create! [{ username: key.split(' ')[1], password_digest: "123456"  }]
	User.find_by(username: key.split(' ')[1]).create_profile( gender: users_gender[key], birth_year: value, first_name: key.split(' ')[0],last_name: key.split(' ')[1])
	#Profile.create! [{ gender: users_gender[key], birth_year: value, first_name: key.split(' ')[0],last_name: key.split(' ')[1]  }]
	User.find_by(username: key.split(' ')[1]).todo_lists.create! [{list_name: key+" todolist",list_due_date: Date.today+(1.year)}]
	#TodoList.create! [{ list_name: key+" todolist", list_due_date: Date.today+(1.year)  }]
	#User.last.todo_lists << TodoList.last
	Array(1..5).each do  |num|
		TodoList.find_by(list_name: key+" todolist").todo_items.create! [{due_date: Date.today+(1.year),title: key.split(' ')[0]+" #{num} to do",description: key.split(' ')[0]+" play Dota2 #{num} times",completed: false  }]
		#TodoItem.create! [{ due_date: Date.today+(1.year), title: key.split(' ')[0]+" #{num} to do",description: key.split(' ')[0]+" play Dota2 #{num} times", completed: false }]
		#TodoList.last.todo_items << TodoItem.last
		end
end


